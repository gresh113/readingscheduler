package scheduler.pages;

import scheduler.assignment.AbstractAssignment;

public interface IHasAssignment {
    AbstractAssignment getAssignment();
}
