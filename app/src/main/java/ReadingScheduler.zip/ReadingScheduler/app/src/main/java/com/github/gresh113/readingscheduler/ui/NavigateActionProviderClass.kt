package io.material.materialthemebuilder.ui

import android.content.Context
import android.view.View
import androidx.core.view.ActionProvider

class NavigateActionProviderClass(context: Context?) : ActionProvider(context) {
    override fun onCreateActionView(): View {
        TODO("Not yet implemented")
    }
}