package scheduler.pages;

public interface IPaged {
    PageSpan getPages();
}
